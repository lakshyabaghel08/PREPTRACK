# MyMPPSC

A **local-first MPPSC State Service Preliminary Examination practice app**. Previous-year paper simulations, topic and custom practice, smart practice, a mistake book, adaptive revision scheduling, analytics and syllabus tracking — all running in your browser, with **no account, no server and no network calls after the page loads**.

> **Bank update:** The bundled bank contains 1,684 questions across 16 papers (2009–2024), including 29 labelled model questions. The 2009 and 2011 papers are incomplete; the 2009–2011 sources are English-only solved transcriptions whose paper identities are unconfirmed. The 2009 paper has 94 unofficial PDF-derived answers, 12 disputed and 40 unresolved; 2010 has 80 unofficial PDF-derived answers, 14 disputed and 26 unresolved, with paper identity unconfirmed; 2011 has 88 unofficial PDF-derived answers, 12 disputed and 18 unresolved, and its paper identity is disputed. The 2012 paper now has 89 independently verified answers (not officially authenticated MPPSC answers), 11 defective or genuinely ambiguous questions deliberately left unkeyed, and full four-part explanations for all 100 questions. Historical scoring remains unknown for 2009–2012. See the [2012 final answer audit](REPORT_FINAL_ANSWER_AUDIT_2012.md), the [PDF review](data/pyq/source/2009-2011/PDF_REVIEW.md) and [2012 transcription notes](data/pyq/source/2012-recovery/TRANSCRIPTION_PROGRESS.md). Older figures below describe the prior bank.

Everything you import and record is stored in IndexedDB on your device. The question bank is data, not code: adding a new paper means importing a JSON file, never rebuilding the app. The repository also ships a classified MPPSC practice bank for **2009–2024** (1,684 available questions, 16 papers) which the app loads **from the repository itself** — a fresh install has the papers without anyone importing a file by hand.

---

## Quick start

```bash
npm install          # only needed to run the tests (fake-indexeddb, jsdom)
npm run serve        # serves the folder on http://localhost:8080
```

Then open <http://localhost:8080/>. On first load the app fetches the bundled bank from `data/pyq/mymppsc-pyq-bank.json`, validates it with the same validator the import screen uses, and writes it to your local database — no upload, no manual import. A **clearly-labelled synthetic demonstration bank** remains one click away (Question Bank & Imports → *Demonstration data*) for exploring screens; it is never presented as genuine previous-year content.

**The bundled bank is transcribed material, not an official source.** The 2009–2011 paper identities have not been independently confirmed. The 1,171 source-record keys in the older bank are supplied but none has been verified against an official MPPSC key: the 2013–2018 packages carry their printed keys, while eight 2019–2024 source omissions were resolved in a committed human review file. No key is called official. The 2012 paper carries independently source-supported `verified_answer` records for 89 questions and leaves 11 defective or ambiguous items unkeyed; none is an authenticated MPPSC key. The latest reported +3/−1/0 marking pattern is used for practice for 2013–2024 at the user’s direction; 2009–2012 scoring is unknown; this is not a claim about the historical rules for each sitting. See `docs/PYQ_AUDIT.md` for the source and classification audit and `REPORT_FINAL_ANSWER_AUDIT_2012.md` for the 2012 answer audit.

Any static file server works — the app is plain HTML/CSS/ES modules. To run it offline as a PWA, serve it over `http(s)` (the service worker cannot register on `file://`).

## The bundled MPPSC bank (repository-backed loading)

```
data/pyq/mymppsc-pyq-bank.json   the classified bank the app loads
js/services/builtin-bank.js      the loader (fetch → validate → import)
js/core/marking.js               the marking schemes the loader writes into papers
sw.js                            precaches the bank, so it works offline
```

* **Fresh install** — on boot the app fetches `data/pyq/mymppsc-pyq-bank.json`,
  validates it with the same validator the import screen uses, and imports it
  through the same two-phase importer. Nothing is uploaded, and there is no
  "choose a file" step.
* **Updates** — a rebuilt bank is picked up on the next load. Idempotence is
  decided by comparing the file with what is stored (new records / changed
  records) plus the recorded SHA-256, not by the file's timestamp: re-opening the
  app, or loading the same bank twice, writes nothing and cannot create
  duplicate questions. A record whose question text and options are unchanged is
  left as it is — the same content identity the rest of the app deduplicates
  on — so a rebuild that changes wording, options, answers, explanations of
  *those* records, or metadata refreshes them, while the rest keep your edits.
* **Your data survives** — the loader imports with the *update, preserving my
  corrections* conflict policy. Your corrections, verified answers, bookmarks,
  attempts, revision history, tests and your own imported questions are kept.
* **Offline** — the bank file is in the service-worker precache list, so after
  the first load the app works with no network.
* **Manual import still works** — for the bundled bank it is simply unnecessary.
  **Question Bank & Imports** shows whether the bundled bank is loaded, offers
  *Check for an updated bundled bank*, and can remove it from this device
  without touching your own data.

The bank is built, and can be rebuilt, from the committed source and review
files — see `docs/PYQ_PIPELINE.md` and `docs/PYQ_AUDIT.md`.

```bash
npm test             # service, UI journey, bank loader, historical-source adapter, PYQ pipeline and analysis suites
npm run check        # static integrity checks for imports, routes, assets, contrast, tokens, shell and the production bank
npm run audit:ui     # alias for npm run check (static UI + contrast + token audit)
python3 tools/make-icons.py   # regenerate the PWA icons (no dependencies)
node tools/build-bank.mjs --help
node tools/classify-bank.mjs --help
```

## Deploying to GitHub Pages

The app is a static site with no build step, so Pages can publish the repository
root directly (**Settings → Pages → Deploy from a branch → `main` / `(root)`**).
Pages serves over HTTPS, which the service worker requires. Four things keep that
working, and `npm run check` fails if any of them is undone:

* **Stay relative.** A project site lives at `https://<user>.github.io/<repo>/`, so a leading slash resolves to the domain root and 404s. Every URL in `index.html`, `sw.js`, `manifest.webmanifest` and `css/app.css` is relative (`css/app.css`, `./js/app.js`), the service worker is registered as `'sw.js'` with `scope: './'`, and its precache list uses `./` prefixes. The same files therefore also work on a custom domain or from `npm run serve` with no changes.
* **Keep an empty `.nojekyll` at the repository root.** Without it Pages runs the tree through Jekyll, which ignores paths that start with an underscore and adds a rebuild step that can drop files.
* **Bump the service-worker cache version** (`const VERSION = 'v1.3.0-1';` in `sw.js`) in the same commit as any change to a precached file — HTML, CSS, JS, icons, demo data. The old caches are deleted on `activate`, which is how a browser that cached a broken shell drops it. If the version did not change, that browser would keep serving the broken files.
* **Verify after deploying:** load the site, check the console for a failed request, then reload once (or unregister the old worker in DevTools → Application → Service Workers) to confirm the new build is the one being served.

## What it does

Every screen opens with the same anatomy — one title, one line saying what the screen is for, one primary action — and the same card layout (one heading, an optional count, at most one ⓘ, at most one action). A density budget is enforced in `npm run check`: at most **8 cards per screen**, **250 words per card** (table text excluded), **3 disclosures**, **2 ⓘ toggles** and **60 controls outside a table**, measured on the rendered screen. On a phone the five most-used destinations sit in a bottom tab bar, wide tables become labelled card rows, and every target is at least 44px.

| Area | Behaviour |
| --- | --- |
| **Start a session** | One sheet — *Practise now* on the dashboard, *Quick practice* in the header, or `#/practise` — asks **what** (smart mix, whole bank, due revision, open mistakes), **how many** and **feedback timing**, then starts. The full **Topic & Custom Practice** screen is one tap away, and the sheet remembers the size and timing you chose. |
| **Topic &amp; Custom Practice** | One screen for both: tick any subjects and topics — the pool is the **union** of what you tick, and nothing ticked means the whole bank. Every count belongs to its own subject, the live line says how many questions match, and attempt history, years, papers, question types, subtopic, language and search tuck behind **Narrow further**. A **strategy** decides which questions are picked; **shuffle question order** decides how they are arranged (off means paper order — year, then paper, then question number). One subject with at most one topic is recorded as a *topic* session, anything wider as a *custom* set, which is always labelled as such and never as an authentic paper. Deep links (`#/topic/<Subject>` or `#/topic/<Subject>||<Topic>`) preselect it — that is what the Insights and dashboard tables link to — and `#/custom` still opens the same screen. |
| **PYQ Test Centre** | Every stored paper in one filterable table (year · paper · questions · duration · scheme · your best · start/resume), with per-row details one control away and unfinished sessions pinned at the top. Full-paper practice runs in the **stored question order** with the paper's duration when available. The bundled 2013–2024 bank uses the latest reported +3/−1/0 scheme as a practice policy, not as evidence of historical rules. Incomplete papers and unknown scoring rules are labelled before you start. The test screen answers to the keyboard; the **?** button lists the shortcuts. | Counts the previous-year questions stored on this device by subject and by topic: a subject bar chart, then a chosen subject's topics as a chart and a short table (count, share, how many papers hold the topic, practice link). What each paper contributed to each group is one tap away behind ⓘ *Year by year*. It stops at the topic level: subtopic labels come from an import, not from the printed paper, so counting them would describe the bank instead of the exam. Every count matches the Question Bank screen's filters and links through to practice on that group. |
| **Smart Practice** | Builds a session from due revisions, repeated mistakes, skipped questions, weak topics, unseen coverage and under-practised topics, and **explains every allocation line**. Historical frequency is described as a study aid, never a prediction. |
| **Mistake Book** | Wrong answers, skips, flagged questions, repeated mistakes and correct-but-unsure answers, with the full attempt history per question. Resolving keeps the history. |
| **Revision Centre** | Due / overdue / upcoming queues where each entry shows the numeric basis for its date (outcome, confidence, level, interval, ease, time taken). Manual override at any time. |
| **Syllabus** | The commission's revised 2026 syllabus as the spine (Prelims and Mains, in its own wording and hierarchy). Mark any topic with one click (not started → in progress → completed → revised), or a whole section at once; headings, papers and the overview add up what is marked. Status is always manual; question-bank linkage is shown separately and never changes it. Every line the commission published in Hindi only carries a **hand-written English rendering** for the English interface, marked as this app's wording wherever it is shown, while the *Official wording* block stays the commission's Hindi verbatim. |
| **Insights → My performance** | Available questions ≠ unique questions attempted ≠ total attempts — the section states the three once, above both tabs, and neither tab mixes them. First-attempt accuracy is reported separately from overall accuracy, small samples are labelled, and every figure comes from stored attempts. |
| **Question Bank & Imports** | Two-phase import (analyse → confirm) with schema/version validation, a pre-import summary, duplicate detection, provenance retention, rejected-record inspection, import history and undo. User corrections (classification, verified answer, dispute flag) are appended, never overwritten. The question list supports **bulk actions**: tick rows (or the whole page), then change their subject/topic — recorded as a correction on each question and undoable from the list — or delete them; each asks first. |
| **Settings & Backup** | Preferences, scoring defaults, revision rules, full JSON backup with SHA-256 integrity, validated restore (merge or replace), storage diagnostics and a guarded destructive zone. |
| **Search, start and find (⌘K / Ctrl K)** | One keyboard-first front door in three groups: **Go** (all thirteen screens), **Do** (start a 20-question set, resume the last test, mark a syllabus line, export a backup) and **Find** (subjects and topics from your bank, syllabus lines, and questions by their text). Every result says where it goes. |
| **Study Timer** | A flip-clock focus workspace: **Pomodoro** (25/30/45/50/90-minute blocks, configurable short and long breaks) or **stopwatch**, with a task line, a live tab title, a distraction-free fullscreen stage, three atmospheres (woodland leaves, rainfall, night sky with meteors) and ambience that is **synthesised in the browser** (no audio files to download) plus an optional mindfulness bell. A finished block is logged automatically; early stops log what was actually worked. The block keeps running while you mark syllabus lines or sit a mock, survives a reload, and every log is filed under a **study day that starts at 4 AM** — a session past midnight belongs to the evening it began. Manual logs cover study that happened away from the timer. |
| **Study hours** | What the timer added up to: current and best streak, this week against last week, average per active day, target met, a 26-week consistency heatmap and the weekly rhythm. The daily focus target lives in the timer's own preferences. |
| **Resume strip** | While a session is in progress, the header says which one, how far it has got and offers **Resume** — on every screen except the runner itself. |
| **Offline / PWA** | Service worker precaches the shell; the app keeps working offline. |

Answer-key integrity is enforced throughout: a **supplied** key is never overwritten, an independently **verified** answer is stored alongside it with evidence, and keys can be **flagged as disputed**. Three test rules are fixed rather than configurable, so every test is scored the same way and results stay comparable: **confidence marking is always optional**, a **verified answer is preferred** over a supplied key, and a **missing or disputed key is judged with the supplied answer** and flagged in the report. The bundled 2013–2024 papers automatically use the latest practice marking pattern (+3/−1/0); the app does not claim that pattern governed every historical sitting.

Starting a practice session is deliberately low-config. On Topic &amp; Custom Practice and Smart Practice the only decisions up front are **what to include**, **how many questions** and **feedback timing**; every other session rule (timing, scoring, option order, repeats) is pre-filled from your Settings defaults, summarised in one plain-language line, and editable under a collapsed **Advanced settings** disclosure. What the screen re-renders, the form you filled in survives.

## What it deliberately does not do

* No login, backend, cloud sync or API calls. No telemetry.
* **No AI or model runs inside the app.** Explanations, answers and classifications are imported data: the app displays them exactly as supplied, says when a question has none, and lets you correct anything with the original preserved. Nothing is generated, and no review status is claimed for prose the app cannot verify.
* No bundled MPPSC syllabus and no claim to official content. The bundled 2013–2024 bank is transcribed previous-year material whose stored keys are **unverified** against official MPPSC keys; its latest-pattern scoring is a practice policy, not historical proof. The demonstration dataset is synthetic filler and badged as such everywhere it appears.
* No exam-prediction claims, no invented questions to "complete" an incomplete paper, and no guarantee that revision makes anything stick.
* No source-book name, coaching provider, page reference or "official/unofficial key" label anywhere in the bundled bank or the interface. That provenance is kept in the build-time reports (`data/pyq/review-report.md`, `docs/PYQ_AUDIT.md`), not in the app.

## Project layout

```
index.html                 app shell
manifest.webmanifest       PWA manifest
sw.js                      service worker (offline shell)
css/app.css                the design system and every screen's styles
css/focus-timer.css        the Study Timer's stage, flip clock, atmospheres and
                           consistency heatmap (imported by index.html after app.css)
js/app.js                  boot, navigation, routing table
js/core/                   constants, db (IndexedDB), schema, validate, state, util
js/services/               scoring, attempts, questions, tests, select, revision,
                           analytics, importer, planner, data (backup),
                           study-timer (the focus engine), study-log (session rows)
js/ui/                     router, components (kit), budget (density limits),
                           practicesheet, flipclock, focus-atmosphere,
                           focus-audio (synthesised ambience), views/ (one file
                           per screen)
data/schema/               versioned question-bank JSON Schema
data/taxonomy/             canonical subject/topic/subtopic vocabulary for the pipeline
data/demo/                 synthetic demonstration bank
data/examples/             schema example + invalid-records fixture
data/pyq/                  PYQ pipeline output: bank, classification + review reports
data/syllabus/             extracted 2026 syllabus, study guide, curated PYQ links,
                           hand-written English renderings of the Hindi-only lines
demo/                      sample intake files for the separate pipeline
tools/                     serve.mjs, check.mjs, density.mjs (renders the screens for
                           the density guard), build-bank.mjs, classify-bank.mjs,
                           classify/ (rule engine, taxonomy, reports, AI queue)
tests/                     node:test suites (services, e2e, UI, tools)
docs/                      schema, data pipeline, testing, limitations, report
```

Layering is strict: `core → services → ui`. Views are HTML strings plus delegated event listeners — no framework, no build step.

## Adding a new paper

1. Produce a bank file that follows `data/schema/question-bank.schema.json` — see `docs/SCHEMA.md`. Question text, options, keys, classifications and explanations come from **your** pipeline, not from this app. For an extracted previous-year paper, `tools/classify-bank.mjs` does the subject/topic/subtopic classification and the integrity reports for you — see `docs/PYQ_PIPELINE.md`.
2. Validate it before importing:
   ```bash
   node tools/build-bank.mjs --validate my-bank.json
   ```
3. In the app: **Question Bank & Imports → Import**, review the pre-import summary (papers, counts, rejected records, warnings, duplicates), choose the conflict policy, then confirm.

`tools/build-bank.mjs` can also convert a simpler *intake* file into a bank file and validate the result with the same validator the app uses — see `docs/DATA_PIPELINE.md` and the runnable example in `demo/`.

## Documentation

| Document | Contents |
| --- | --- |
| `docs/UI.md` | The design system: colour tokens (Light/Dark/Forced-colors) and contrast ratios, Devanagari typography, provenance components, accessibility contract, enumerated `!important` rules, and automated UI guards. |
| `docs/SCHEMA.md` | The question-bank JSON schema: every field, versioning rules, validation behaviour. |
| `docs/DATA_PIPELINE.md` | How to produce banks outside the app, with the intake format and worked example. |
| `docs/PYQ_PIPELINE.md` | The PYQ classification pipeline: the rule engine, the taxonomy, MP-versus-India attribution, the extraction repairs, the human review pass, the app-facing sanitiser and the reports it writes. |
| `docs/MARKING.md` | The latest reported +3/−1/0 pattern used uniformly for practice from 2013 onward, the user-directed retroactive application caveat, and the evidence limitations. |
| `docs/PYQ_AUDIT.md` | Internal audit of the bundled 2013–2024 bank: 1,171 questions across 12 papers, six strict historical source adapters, source/report checks, repairs, classification coverage, unresolved content, answer-key caveats, and marking policy. |
| `docs/TESTING.md` | What the test suite covers, what it does not, and a manual verification checklist. |
| `docs/LIMITATIONS.md` | Honest list of what this build does not do or cannot guarantee. |
| `docs/IMPLEMENTATION_REPORT.md` | Feature-by-feature report against the original specification, the UI overhaul before/after measurements, the tests actually run and their results, and the remaining gaps. |

## Privacy and durability

Your data never leaves the device, which also means **you are responsible for backups**. Browser storage can be cleared by you, by the browser, or when a device runs out of space. Use **Settings & Backup → Download backup** (or `Backup now` in the sidebar) and keep the JSON file outside the browser. The restore path validates structure and verifies the SHA-256 recorded inside the file before writing anything.

## Licence and content notice

The application code is provided as-is for personal study use. Content in this repository is study material, not commission material: the bundled 2013–2024 bank is transcribed previous-year material (1,171 questions across twelve papers, every one carrying a supplied key; none verified against an official key; two legacy extraction records unrecovered — see `docs/PYQ_AUDIT.md`), the demonstration bank and the sample intake file are synthetic filler, and the marking schemes say which patterns are verified and which are only reported. Verify any key against the commission's own key before relying on it, and treat scores as practice feedback, not results.
