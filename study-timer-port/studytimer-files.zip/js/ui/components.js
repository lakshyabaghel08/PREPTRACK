/**
 * components.js — Dependency-free UI & provenance building blocks.
 *
 * Views build HTML strings with these helpers and attach behaviour in `mount()`
 * using event delegation. Zero inline style attributes are emitted here so
 * all visual rules remain governed by css/app.css tokens.
 */

import { esc, fmtPct, fmtMarks, fmtDate, fmtClock, fmtDuration, round, clamp } from '../core/util.js';
import { QUESTION_TYPES, CONFIDENCE_LEVELS, LANGUAGE_LABELS } from '../core/constants.js';

export { esc, fmtPct, fmtMarks, fmtDate, fmtClock, fmtDuration, round };

/* --------------------------------------------------------------- icons ---- */

const ICONS = {
  dashboard: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  'test-centre': '<path d="M9 3h6a2 2 0 0 1 2 2v1h2a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h2V5a2 2 0 0 1 2-2zm0 3h6V5H9v1zm-1 5h8m-8 4h5"/>',
  topic: '<path d="M4 6h16M4 12h16M4 18h10"/><circle cx="18" cy="18" r="2"/>',
  custom: '<path d="M4 21v-7m0-4V3m8 18v-9m0-4V3m8 18v-5m0-4V3M1 14h6m2-6h6m2 8h6"/>',
  smart: '<path d="M12 2l2.4 7.2L22 12l-7.6 2.8L12 22l-2.4-7.2L2 12l7.6-2.8L12 2z"/>',
  mistakes: '<path d="M12 9v4m0 4h.01M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>',
  revision: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8m0-5v5h5m4-1v5l3 2"/>',
  syllabus: '<path d="M9 11l3 3L22 4M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>',
  analytics: '<path d="M18 20V10M12 20V4M6 20v-6"/>',
  'pyq-analysis': '<path d="M4 19h16M6 15V8m5 7V5m5 10v-4"/><path d="M3 21h18"/>',
  bank: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9c.26.6.77 1.02 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
  help: '<circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3m.08 4h.01"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
  sun: '<circle cx="12" cy="12" r="5"/><path d="M12 1v2m0 18v2M4.22 4.22l1.42 1.42m12.72 12.72 1.42 1.42M1 12h2m18 0h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/>',
  moon: '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>',
  print: '<path d="M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/>',
  flag: '<path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1zM4 22v-7"/>',
  close: '<path d="M18 6 6 18M6 6l12 12"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  bookmark: '<path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>',
  'arrow-right': '<path d="M5 12h14m-6-6 6 6-6 6"/>',
  'book-open': '<path d="M12 7v14m0-14C9 4 5 4 2 5v15c4-1 7-1 10 1 3-2 6-2 10-1V5c-3-1-7-1-10 2z"/>',
  shield: '<path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6l8-3z"/><path d="m8 12 3 3 5-6"/>',
  target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
  calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
  // Study Timer: the workspace itself, its ambience, and the fullscreen stage.
  timer: '<circle cx="12" cy="13" r="8"/><path d="M12 9v4l2.5 2M9 2h6"/>',
  sound: '<path d="M11 5 6 9H3v6h3l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13"/>',
  expand: '<path d="M8 3H5a2 2 0 0 0-2 2v3m13-5h3a2 2 0 0 1 2 2v3M8 21H5a2 2 0 0 1-2-2v-3m13 5h3a2 2 0 0 0 2-2v-3"/>',
};

export function icon(name, { size = 16, label = null } = {}) {
  const inner = ICONS[name] || ICONS.help;
  const aria = label ? `role="img" aria-label="${esc(label)}"` : 'aria-hidden="true"';
  return `<svg class="svg-icon" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ${aria}>${inner}</svg>`;
}

/** Detect Devanagari characters so Hindi strings can be marked with lang="hi". */
export function hasDevanagari(text) {
  return typeof text === 'string' && /[\u0900-\u097F]/.test(text);
}

export function langAttr(text, explicitLang = null) {
  if (explicitLang === 'hi' || hasDevanagari(text)) return ' lang="hi"';
  if (explicitLang === 'en') return ' lang="en"';
  return '';
}

/* ----------------------------------------------------- provenance vocabulary */

const SOURCE_META = {
  measured: { cls: 'measured', label: 'measured', title: 'Directly measured from your recorded attempts in this browser' },
  derived: { cls: 'derived', label: 'derived', title: 'Calculated deterministically from your recorded attempts and rules' },
  unavailable: { cls: 'unavailable', label: 'unavailable', title: 'Not supplied in the source data — never guessed or invented' },
  synthetic: { cls: 'synthetic', label: 'synthetic demo', title: 'Synthetic demonstration content — not a genuine MPPSC question' },
  supplied: { cls: 'supplied', label: 'from your data', title: 'Taken directly from the records stored in this browser (the imported bank or your own edits)' },
  verified: { cls: 'verified', label: 'verified key', title: 'Independently verified and recorded in the question bank' },
  disputed: { cls: 'disputed', label: 'disputed', title: 'Answer key is disputed or unresolved' },
};

/**
 * Render a consistent provenance source chip:
 * `measured` | `derived` | `unavailable` | `synthetic` | `supplied` | `verified` | `disputed`
 */
export function sourceChip(kind, customLabel = null) {
  const meta = SOURCE_META[kind] || SOURCE_META.measured;
  const text = customLabel || meta.label;
  return `<span class="prov-chip ${meta.cls}" data-source="${esc(kind || 'measured')}" title="${esc(meta.title)}">${esc(text)}</span>`;
}

/**
 * Render a 3-step evidence-strength meter (`n=0..3+`).
 * Samples with `< minSample` judged questions are visually distinct so the user
 * never mistakes a 1-question sample for a reliable topic assessment.
 */
export function evidenceMeter(judgedCount, minSample = 3, { showLabel = true } = {}) {
  const n = Math.max(0, Number(judgedCount) || 0);
  const steps = Math.min(3, n);
  const insufficient = n < minSample;
  // The class names must match css/app.css (`.evidence-meter.insufficient` /
  // `.solid`, `.evidence-pips` / `.evidence-pip`). This used to emit
  // `.evidence-dot` and `sufficient`, which nothing styled: the three steps
  // were empty inline <i> elements (0 × 0 px, invisible) and a met threshold
  // looked the same as a neutral chip.
  const cls = insufficient ? 'insufficient' : 'solid';
  // Plain words on the surface; the sample-size maths stays in the tooltip.
  const label = insufficient ? (n === 0 ? 'no attempts yet' : `only ${n} attempt${n === 1 ? '' : 's'} so far`) : `${n} attempt${n === 1 ? '' : 's'}`;
  const title = insufficient
    ? `Insufficient evidence: ${n} of ${minSample} required judged attempts recorded`
    : `Evidence threshold met: ${n} judged attempts recorded (min ${minSample})`;
  return `<span class="evidence-meter ${cls}" title="${esc(title)}" role="img" aria-label="${esc(title)}">
    <span class="evidence-pips" aria-hidden="true">
      <i class="evidence-pip ${steps >= 1 ? 'on' : ''}"></i>
      <i class="evidence-pip ${steps >= 2 ? 'on' : ''}"></i>
      <i class="evidence-pip ${steps >= 3 ? 'on' : ''}"></i>
    </span>
    ${showLabel ? `<span>${esc(label)}</span>` : ''}
  </span>`;
}

export function provenanceLine({ source = 'measured', text = '' } = {}) {
  return `<div class="prov-line">${sourceChip(source)}<span>${esc(text)}</span></div>`;
}

/**
 * Collapsed "ⓘ" disclosure for explanations, provenance and other background
 * detail. The short summary is all that shows; the longer text is one tap
 * away instead of filling the screen. Built on native <details>, so it works
 * with keyboard, mouse and touch with no JavaScript.
 * `body` is trusted HTML (callers escape user text, as everywhere else).
 */
export function infoToggle(summary, body, { open = false, className = '' } = {}) {
  if (!body) return '';
  return `<details class="info-toggle${className ? ` ${esc(className)}` : ''}"${open ? ' open' : ''}>
    <summary><span class="info-i" aria-hidden="true">i</span><span>${esc(summary)}</span></summary>
    <div class="info-body">${body}</div>
  </details>`;
}

/** A short visible line plus the long explanation tucked into an infoToggle. */
export function infoNote(shortText, longHtml, summary = 'More about this') {
  return `<div class="info-note"><span>${shortText}</span>${infoToggle(summary, longHtml)}</div>`;
}

/* --------------------------------------------------------------- basics --- */

export const badge = (text, tone = '') => `<span class="badge ${tone}">${esc(text)}</span>`;

export const demoBadge = (isDemo) =>
  isDemo
    ? '<span class="demo-flag" title="Synthetic demonstration content — not a genuine previous-year question">demonstration</span>'
    : '';

/**
 * A screen's single title block (see docs/UI.md §6).
 *
 *   <header class="screen-head">
 *     <h1>…</h1>                     ← the only h1 on the screen
 *     <p class="screen-purpose">…</p> ← one line: what this screen is for
 *     <div class="screen-actions">    ← one primary, then secondary actions
 *   </header>
 *
 * Every screen renders exactly one of these through `screenHead()`, so the
 * heading level, the purpose line and the action placement cannot drift
 * screen by screen. `primary` and `secondary` are trusted markup.
 */
export function screenHead({ title, eyebrow = '', purpose = '', primary = '', secondary = '', className = '' } = {}) {
  return `<header class="screen-head ${esc(className)}">
    <div class="screen-head-text">
      ${eyebrow ? `<p class="eyebrow">${esc(eyebrow)}</p>` : ''}
      <h1>${title}</h1>
      ${purpose ? `<p class="screen-purpose">${purpose}</p>` : ''}
    </div>
    ${primary || secondary ? `<div class="screen-actions">${primary}${secondary ? `<div class="screen-actions-secondary">${secondary}</div>` : ''}</div>` : ''}
  </header>`;
}

/**
 * A count chip for a card's title row: "12", "3 of 12", "42 questions".
 * It is a chip, not a heading, so the card keeps exactly one h2.
 */
export const countChip = (text, tone = '') => `<span class="count-chip ${esc(tone)}">${esc(String(text))}</span>`;

/**
 * One card, one fixed anatomy (docs/UI.md §7):
 *
 *   .card-head  → h2 + optional count chip + at most one ⓘ + at most one action
 *   .card-body
 *   .card-foot  (optional)
 *
 * `actions` and `right` are kept as the same single slot for older callers that
 * pass one control; a caller that needs several controls puts a `.card-toolbar`
 * row at the top of `body` instead, so the title row stays one line.
 */
export function card({ title = null, subtitle = null, count = null, info = '', action = '', actions = '', right = '', body = '', footer = null, tone = '', id = null, className = '', heading = 2 } = {}) {
  const level = Number(heading) >= 2 && Number(heading) <= 4 ? Number(heading) : 2;
  const countText = count === null || count === undefined ? '' : String(count).trim();
  // Support legacy chips produced by countChip; new callers should pass plain text.
  const countHtml = !countText ? ''
    : countText.startsWith('<span class="count-chip') ? countText : countChip(countText);
  const actionContent = action || actions || right;
  const hasHead = title || subtitle || actionContent;
  const head = hasHead
    ? `<div class="card-head">
        <div class="card-head-text">
          <div class="card-title-row">${title ? `<h${level}>${title}</h${level}>` : ''}${countHtml}${info}</div>
          ${subtitle ? `<div class="card-subtitle muted small">${subtitle}</div>` : ''}
        </div>
        ${actionContent ? `<div class="card-action">${actionContent}</div>` : ''}
      </div>`
    : '';
  return `<section class="card ${tone} ${className}" ${id ? `id="${esc(id)}"` : ''}>
    ${head}
    <div class="card-body">${body}</div>
    ${footer === null || footer === '' ? '' : `<div class="card-foot">${footer}</div>`}
  </section>`;
}

/**
 * The card's one ⓘ: methodology, provenance and definitions live here rather
 * than on the surface. Every screen may carry at most two of these (the density
 * budget in tools/check.mjs enforces it), so a card title row shows at most one.
 */
export const cardInfo = (summary, body) => infoToggle(summary, body, { className: 'card-info' });

/**
 * A sticky tab bar for a screen (`<div class="screen-tabs">`). Same APG
 * behaviour as `tabs()`, including `mountTabs()`, with a class that makes it
 * stick under the header.
 */
export function screenTabs({ id = '', items = [], activeId = null } = {}) {
  if (!items.length) return '';
  const selectedId = activeId || items[0].id;
  return `<div class="tabs screen-tabs" role="tablist" ${id ? `id="${esc(id)}"` : ''} aria-label="Sections">
    ${items
      .map((item) => {
        const isSelected = item.id === selectedId;
        return `<button class="tab" role="tab" type="button" data-tab="${esc(item.id)}" aria-selected="${isSelected}" tabindex="${isSelected ? '0' : '-1'}" aria-controls="${esc(item.id)}-panel" id="${esc(item.id)}-tab">${esc(item.label)}</button>`;
      })
      .join('')}
  </div>
  ${items
    .map((item) => {
      const isSelected = item.id === selectedId;
      const panelHtml = item.body ?? item.content ?? '';
      return `<div class="tabpanel" id="${esc(item.id)}-panel" role="tabpanel" tabindex="0" aria-labelledby="${esc(item.id)}-tab" ${isSelected ? '' : 'hidden'}>${panelHtml}</div>`;
    })
    .join('')}`;
}

/**
 * Per-screen filter memory.
 *
 * Every filtered screen re-renders itself in place when a filter changes, and a
 * reader who comes back to the screen expects the filters they set to still be
 * on. The state lives for the lifetime of the page, one entry per screen — the
 * same rule the session form uses (`views/shared.js`). `count` reports how many
 * values differ from the defaults, which is what the "N filters on" chip shows.
 */
export function createFilterState(defaults) {
  const initial = { ...defaults };
  let current = { ...defaults };
  return {
    get: () => ({ ...current }),
    set(patch) {
      current = { ...current, ...patch };
      return { ...current };
    },
    reset() {
      current = { ...initial };
      return { ...current };
    },
    count() {
      return Object.keys(initial).filter((key) => {
        const value = current[key];
        const base = initial[key];
        if (Array.isArray(base)) return (Array.isArray(value) ? value : []).length !== base.length;
        if (typeof base === 'boolean') return value !== base;
        return String(value) !== String(base);
      }).length;
    },
  };
}

/**
 * "N filters on" chip + one way to clear them. Every filtered screen shows one
 * when filters are active, so a reader can always tell why the list is short.
 */
export function filterChip(count, { clearAction = 'clear-filters', unit = 'filter' } = {}) {
  if (!count) return '';
  return `<span class="filter-chip" data-filter-count="${count}">
    <strong>${count} ${esc(unit)}${count === 1 ? '' : 's'} on</strong>
    <button class="btn btn-quiet btn-sm" type="button" data-action="${esc(clearAction)}">Clear</button>
  </span>`;
}

/**
 * "Show all" under a capped list. `hidden` names how many rows are held back;
 * the control only appears when there are any, so a short list never carries a
 * dead button.
 */
export function showAll({ action = 'show-all', hidden = 0, label = 'Show all' } = {}) {
  if (!hidden) return '';
  return `<div class="show-all-row"><button class="btn btn-sm" type="button" data-action="${esc(action)}">${esc(label)} <span class="muted">(+${hidden})</span></button></div>`;
}

export function tile({ label, value, sub = '', tone = '' }) {
  // Tiles used to carry a provenance chip and a "where this came from" line on
  // every stat. That metadata now lives behind the screens' ⓘ disclosures, so
  // a tile is just the number and what it counts. (`source`/`where` arguments
  // from older callers are accepted and ignored.)
  return `<div class="tile ${tone}">
    <div class="tile-label"><span>${esc(label)}</span></div>
    <div class="tile-value">${value}</div>
    ${sub ? `<div class="tile-sub">${sub}</div>` : ''}
  </div>`;
}

export function notice(html, tone = 'info', { title = null } = {}) {
  return `<div class="notice ${tone}">${title ? `<strong>${esc(title)}</strong> ` : ''}${html}</div>`;
}

/**
 * An empty state with exactly one way forward (docs/UI.md §6d).
 *
 * `willShow` names what appears here once the action is taken, so an empty
 * screen never leaves the reader guessing what it is for. Callers pass one
 * action — a button (`action`) or a link (`actionHref` + `actionLabel`) — never
 * both; the density suite checks it.
 */
export const emptyState = ({ title, message = '', body = '', action = '', actionHref = null, actionLabel = '', willShow = '' } = {}) => {
  const text = message || body;
  const actionHtml = action || (actionHref && actionLabel ? `<a class="btn btn-primary" href="${esc(actionHref)}">${esc(actionLabel)}</a>` : '');
  return `<div class="empty-block"><strong>${esc(title)}</strong>${text ? `<p class="muted small">${text}</p>` : ''}${willShow ? `<p class="empty-what tiny">${esc(willShow)}</p>` : ''}${actionHtml ? `<div class="empty-actions">${actionHtml}</div>` : ''}</div>`;
};

export const loadingState = (message = 'Loading local data…') =>
  `<div class="loading-block" aria-busy="true" role="status">${esc(message)}</div>`;

/* ------------------------------------------------------------ skeletons --- */

/**
 * Skeleton placeholder for a screen that is still reading its data: grey
 * blocks in the rough shape of what is coming, instead of a line of text.
 *
 * - The wrapper is the status region. It carries one visually hidden sentence
 *   for assistive technology — the same words `loadingState()` shows — and
 *   every block inside it is `aria-hidden`.
 * - Blocks are coloured from tokens, keep a transparent border so they still
 *   draw as outlines in forced-colours mode, and pulse only when the OS allows
 *   motion (`css/app.css`, "Skeleton placeholders").
 * - Purely presentational: no headings, no controls, nothing focusable.
 *
 * `parts` are strings built with the `skeleton.*` helpers below; the screen
 * layouts themselves live in `js/ui/skeletons.js`.
 */
export function skeletonScreen(parts = [], { label = 'Loading local data…' } = {}) {
  return `<div class="skeleton" role="status" aria-busy="true"><span class="sr-only">${esc(label)}</span><div class="skeleton-body" aria-hidden="true">${parts.join('')}</div></div>`;
}

/** Widths cycled through so placeholder lines do not look like a ruled pad. */
const SKELETON_WIDTHS = ['sk-w90', 'sk-w70', 'sk-w80', 'sk-w55', 'sk-w65'];
const times = (count, make) => Array.from({ length: Math.max(0, count) }, (_, i) => make(i)).join('');

export const skeleton = {
  /** Stands in for the screen's `<h1>` and, optionally, its one-line lede. */
  heading: ({ lede = true } = {}) =>
    `<div class="skeleton-heading"><span class="skeleton-block skeleton-title"></span>${lede ? '<span class="skeleton-line sk-w70"></span>' : ''}</div>`,
  /** `count` lines of text; the last one is short, like the end of a paragraph. */
  lines: (count = 3) =>
    `<div class="skeleton-stack">${times(count, (i) => `<span class="skeleton-line ${i === count - 1 && count > 1 ? 'sk-w40' : SKELETON_WIDTHS[i % SKELETON_WIDTHS.length]}"></span>`)}</div>`,
  /** A row of stat tiles laid out by a real grid class (`.grid.tiles` by default). */
  tiles: (count = 4, { className = 'grid tiles' } = {}) =>
    `<div class="${esc(className)}">${times(count, () => '<div class="skeleton-tile"><span class="skeleton-line sk-w55"></span><span class="skeleton-block skeleton-value"></span><span class="skeleton-line sk-w80"></span></div>')}</div>`,
  /** A tab bar with `count` tabs. */
  tabs: (count = 2) => `<div class="skeleton-tabs">${times(count, () => '<span class="skeleton-block skeleton-tab"></span>')}</div>`,
  /** A card — the real `.card` box, so padding, radius and shadow match — with a heading bar. */
  card: (body = '', { head = true } = {}) =>
    `<div class="card skeleton-card">${head ? '<div class="card-head"><span class="skeleton-line skeleton-card-title"></span></div>' : ''}<div class="card-body">${body}</div></div>`,
  /** Table rows of `cols` cells (the first one wider); `check` adds a leading checkbox cell. */
  table: (rows = 6, cols = 4, { check = false } = {}) =>
    `<div class="skeleton-table">${times(
      rows,
      (r) =>
        `<div class="skeleton-row">${check ? '<span class="skeleton-block skeleton-check"></span>' : ''}${times(
          cols,
          (c) => `<span class="skeleton-cell${c === 0 ? ' wide' : ''}"><span class="skeleton-line ${SKELETON_WIDTHS[(r + c) % SKELETON_WIDTHS.length]}"></span></span>`,
        )}</div>`,
    )}</div>`,
  /** Horizontal bar-chart rows: a label and a bar of varying length. */
  chart: (bars = 6) =>
    `<div class="skeleton-chart">${times(bars, (i) => `<div class="skeleton-chart-row"><span class="skeleton-line skeleton-chart-label"></span><span class="skeleton-cell"><span class="skeleton-block skeleton-bar ${SKELETON_WIDTHS[(i * 2) % SKELETON_WIDTHS.length]}"></span></span></div>`)}</div>`,
  /** Labelled form fields, laid out like a `.filters` row. */
  fields: (count = 4) =>
    `<div class="skeleton-fields">${times(count, () => '<span class="skeleton-field"><span class="skeleton-line sk-w40"></span><span class="skeleton-block skeleton-control"></span></span>')}</div>`,
  /** A row of buttons. */
  buttons: (count = 2) => `<div class="skeleton-buttons">${times(count, () => '<span class="skeleton-block skeleton-button"></span>')}</div>`,
};

export const kv = (pairs = []) =>
  `<dl class="kv">${pairs
    .map(([k, v]) => `<dt>${esc(k)}</dt><dd>${v === null || v === undefined || v === '' ? '<span class="soft">not recorded</span>' : v}</dd>`)
    .join('')}</dl>`;

/* ---------------------------------------------------------------- tables -- */

/**
 * Supports both `{ columns: [{ label, num }], rows, footer }` and `{ headers: ['...'], rows }`.
 *
 * A column may also carry `className` (added to its `<th>` and every `<td>`)
 * and `headerHtml` — trusted markup for the header cell, such as a
 * select-all checkbox; `label` still names the column for `data-label`.
 * A row is normally an array of cells; `{ cells, className }` adds a class to
 * its `<tr>`.
 */
export function dataTable({ columns = null, headers = [], rows = [], footer = null, empty = 'Nothing to show.', className = '' } = {}) {
  if (!rows.length) return `<p class="muted small m-0">${esc(empty)}</p>`;
  const cols = columns || headers.map((h) => (typeof h === 'string' ? { label: h, num: false } : h));
  const cellClass = (col) => {
    const names = [col?.num ? 'num' : '', col?.className || ''].filter(Boolean).join(' ');
    return names ? `class="${esc(names)}"` : '';
  };
  const footHtml =
    Array.isArray(footer) && footer.length
      ? `<tfoot><tr>${footer
          .map((cell, i) => {
            const col = cols[i];
            return `<td ${cellClass(col)}>${cell ?? ''}</td>`;
          })
          .join('')}</tr></tfoot>`
      : '';
  return `<div class="table-wrap"><table class="data ${className}">
    <thead><tr>${cols.map((c) => `<th ${cellClass(c)}>${c.headerHtml ?? esc(c.label)}</th>`).join('')}</tr></thead>
    <tbody>${rows
      .map((r) => {
        const cells = Array.isArray(r) ? r : r?.cells || [];
        const rowClass = !Array.isArray(r) && r?.className ? ` class="${esc(r.className)}"` : '';
        const main = `<tr${rowClass}>${cells
          .map((cell, i) => {
            const col = cols[i];
            const labelAttr = col?.label ? ` data-label="${esc(col.label)}"` : '';
            return `<td ${cellClass(col)}${labelAttr}>${cell ?? ''}</td>`;
          })
          .join('')}</tr>`;
        // An optional second row holds a panel opened from the row itself
        // (question review, paper details). It keeps the reader's place in the
        // table instead of replacing it with a dialog.
        const detail = !Array.isArray(r) && r?.detail
          ? `<tr class="row-detail-row"${r.detailId ? ` id="${esc(r.detailId)}"` : ''}${r.detailHidden ? ' hidden' : ''}>
              <td colspan="${cols.length}">${r.detail}</td>
            </tr>`
          : '';
        return main + detail;
      })
      .join('')}</tbody>${footHtml}
  </table></div>`;
}

/* --------------------------------------------------------------- visuals -- */

export function barList(items = [], optsOrMax = {}) {
  if (!items.length) return '<p class="muted small m-0">No data yet.</p>';
  const maxOpt = typeof optsOrMax === 'number' ? optsOrMax : optsOrMax?.max ?? null;
  const maxVal = Math.max(...items.map((i) => Number(i.value) || 0), 0);
  const ceiling = maxOpt || (maxVal <= 1 && maxVal > 0 ? 1 : Math.max(maxVal, 1));
  return `<div class="bar-list">${items
    .map((item) => {
      const value = Number(item.value) || 0;
      const pctWidth = clamp((value / ceiling) * 100, 0, 100);
      return `<div class="bar-item">
        <span class="nowrap" title="${esc(item.label)}">${esc(item.label)}</span>
        <svg class="bar-svg" viewBox="0 0 100 8" preserveAspectRatio="none" aria-hidden="true">
          <rect class="bar-bg" x="0" y="0" width="100" height="8" rx="4" ry="4"></rect>
          <rect class="bar-fg ${esc(item.tone || '')}" x="0" y="0" width="${pctWidth.toFixed(1)}" height="8" rx="4" ry="4"></rect>
        </svg>
        <span class="num tiny muted">${item.right ?? esc(String(value))}</span>
      </div>`;
    })
    .join('')}</div>`;
}

export function progressBar(valueOrFraction, maxOrTone = '', maybeTone = '') {
  let pctWidth;
  let tone = '';
  if (typeof maxOrTone === 'number') {
    const safeMax = Math.max(1, maxOrTone);
    pctWidth = clamp(((Number(valueOrFraction) || 0) / safeMax) * 100, 0, 100);
    tone = maybeTone || '';
  } else {
    pctWidth = clamp((Number(valueOrFraction) || 0) * 100, 0, 100);
    tone = maxOrTone || '';
  }
  return `<svg class="progress-svg" viewBox="0 0 100 8" preserveAspectRatio="none" role="img" aria-label="${Math.round(pctWidth)}% complete">
    <rect class="progress-bg" x="0" y="0" width="100" height="8" rx="4" ry="4"></rect>
    <rect class="progress-fg ${esc(tone)}" x="0" y="0" width="${pctWidth.toFixed(1)}" height="8" rx="4" ry="4"></rect>
  </svg>`;
}

function computeAxisTicks(maxVal) {
  const safeMax = Number.isFinite(maxVal) && maxVal > 0 ? maxVal : 1;
  if (safeMax <= 5) {
    const ceil = Math.max(1, Math.ceil(safeMax));
    const ticks = [];
    for (let i = 0; i <= ceil; i += 1) ticks.push(i);
    return { domainMax: ceil, ticks };
  }
  const roughStep = safeMax / 5;
  const mag = 10 ** Math.floor(Math.log10(roughStep));
  const norm = roughStep / mag;
  const mult = norm <= 1 ? 1 : norm <= 2 ? 2 : norm <= 2.5 ? 2.5 : norm <= 5 ? 5 : 10;
  const cleanStep = Math.max(1, Math.round(mult * mag));
  const domainMax = Math.max(cleanStep, Math.ceil(safeMax / cleanStep) * cleanStep);
  const ticks = [];
  for (let v = 0; v <= domainMax; v += cleanStep) {
    ticks.push(v);
  }
  return { domainMax, ticks };
}

/**
 * Horizontal bar chart (SVG) with collision-free labels, end-of-bar totals,
 * axis grid lines, hover tooltips, and accessible table fallback.
 */
export function barChart(arg1 = {}, arg2 = {}) {
  const isArrayArg = Array.isArray(arg1);
  const rawData = isArrayArg ? arg1 : arg1.data || [];
  const opts = isArrayArg ? arg2 : arg1;
  const valueFormat = opts.valueFormat || ((v) => String(Math.round(Number(v) || 0)));
  const yLabel = opts.yLabel || opts.title || 'Bar chart';
  // Column headings of the accessible data table. They default to the subject
  // chart's wording, which every older caller relies on.
  const labelHeader = opts.labelHeader || 'Subject';
  const valueHeader = opts.valueHeader || 'Questions';
  const shareHeader = opts.shareHeader || 'Share';
  // A caller that renders the same rows as its own table right under the chart
  // (with actions the data table cannot carry) can drop the duplicate.
  const withDataTable = opts.dataTable !== false;

  const data = rawData.map((d) => {
    const rawVal = Number(d?.value);
    const value = Number.isFinite(rawVal) ? Math.max(0, rawVal) : 0;
    const rawShare = Number(d?.share);
    const share = Number.isFinite(rawShare) ? clamp(rawShare, 0, 1) : null;
    const fullLabel = String(d?.label ?? '—');
    const displayLabel = fullLabel.length > 34 ? `${fullLabel.slice(0, 33)}…` : fullLabel;
    return {
      ...d,
      label: fullLabel,
      displayLabel,
      value,
      share,
    };
  });

  if (!data.length) return '<p class="muted small m-0">No data to chart yet.</p>';

  const w = 760;
  // The label column fits the longest label (topic names run longer than
  // subject names; a fixed column clipped them at the chart's left edge).
  // ~7.2 user units per character at the label's size and hover weight.
  const longestLabel = Math.max(...data.map((d) => d.displayLabel.length));
  const padL = Math.min(320, Math.max(192, Math.ceil(longestLabel * 7.2) + 20));
  const padR = 112;
  const padT = 10;
  const padB = 28;
  const rowH = 30;
  const barH = 14;
  const innerW = w - padL - padR;
  const innerH = data.length * rowH;
  const h = padT + innerH + padB;

  const maxVal = Math.max(...data.map((d) => d.value), 1);
  const { domainMax, ticks } = computeAxisTicks(maxVal);

  const gridLines = ticks
    .map((tick) => {
      const x = padL + (tick / domainMax) * innerW;
      return `<line class="grid-line" x1="${x.toFixed(1)}" y1="${padT}" x2="${x.toFixed(1)}" y2="${(padT + innerH).toFixed(1)}"></line><text class="axis-label" x="${x.toFixed(1)}" y="${(h - 7).toFixed(1)}" text-anchor="middle">${esc(valueFormat(tick))}</text>`;
    })
    .join('');

  const axisBaseline = `<line class="axis-baseline" x1="${padL}" y1="${padT}" x2="${padL}" y2="${(padT + innerH).toFixed(1)}"></line>`;

  const bars = data
    .map((d, i) => {
      const rowY = padT + i * rowH;
      const barY = rowY + (rowH - barH) / 2;
      const textY = rowY + rowH / 2 + 4;
      const rawBw = (d.value / domainMax) * innerW;
      const bw = d.value > 0 ? Math.max(4, Math.min(innerW, rawBw)) : 0;
      const formattedVal = valueFormat(d.value);
      const endText = d.endLabel || (d.share !== null ? `${formattedVal} (${fmtPct(d.share, 1)})` : formattedVal);
      const tooltip = d.tooltip || `${d.label}: ${endText}`;
      const valX = padL + bw + 8;

      return `<g class="chart-row" tabindex="0" data-chart-label="${esc(d.label)}" data-chart-detail="${esc(tooltip)}">
        <title>${esc(tooltip)}</title>
        <rect class="chart-row-hit" x="4" y="${(rowY + 1).toFixed(1)}" width="${w - 8}" height="${rowH - 2}" rx="6" ry="6"></rect>
        <text class="chart-subject-label" x="${padL - 12}" y="${textY.toFixed(1)}" text-anchor="end">${esc(d.displayLabel)}</text>
        <rect class="bar-track-bg" x="${padL}" y="${barY.toFixed(1)}" width="${innerW}" height="${barH}" rx="4" ry="4"></rect>
        <rect class="bar ${esc(d.tone || '')}" x="${padL}" y="${barY.toFixed(1)}" width="${bw.toFixed(1)}" height="${barH}" rx="4" ry="4"></rect>
        <text class="chart-value-label" x="${valX.toFixed(1)}" y="${textY.toFixed(1)}" text-anchor="start">${esc(endText)}</text>
      </g>`;
    })
    .join('');

  const tableRows = data
    .map(
      (d) =>
        `<tr><td>${esc(d.label)}</td><td class="num">${esc(valueFormat(d.value))}</td>${
          d.share !== null ? `<td class="num">${esc(fmtPct(d.share, 1))}</td>` : ''
        }</tr>`,
    )
    .join('');
  const hasShareCol = data.some((d) => d.share !== null);

  return `<div class="chart-wrap pyq-hbar-wrap">
    <svg class="chart pyq-hbar-chart" viewBox="0 0 ${w} ${h}" role="img" aria-label="${esc(yLabel)}">${gridLines}${bars}${axisBaseline}</svg>
    ${
      withDataTable
        ? `<details class="chart-data"><summary>Data table (${data.length} rows)</summary>
      <div class="table-wrap mt-2"><table class="data compact"><thead><tr><th>${esc(labelHeader)}</th><th class="num">${esc(valueHeader)}</th>${hasShareCol ? `<th class="num">${esc(shareHeader)}</th>` : ''}</tr></thead><tbody>${tableRows}</tbody></table></div>
    </details>`
        : ''
    }
  </div>`;
}

export function sparkline(values = [], { width = 120, height = 26 } = {}) {
  if (!values.length) return '';
  const max = Math.max(...values, 1);
  const step = values.length > 1 ? width / (values.length - 1) : width;
  const path = values.map((v, i) => `${i === 0 ? 'M' : 'L'}${(i * step).toFixed(1)},${(height - (v / max) * (height - 2) - 1).toFixed(1)}`).join(' ');
  return `<svg class="chart" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" aria-hidden="true"><path class="line" d="${path}"></path></svg>`;
}

/* ------------------------------------------------------ display helpers --- */

export const pct = (value, digits = 0) => (Number.isFinite(value) ? fmtPct(value, digits) : '<span class="soft">—</span>');

export function accuracyCell(accuracyOrObj, scoredOrNull = null, minSample = 3) {
  let accuracy = accuracyOrObj;
  let judged = scoredOrNull;
  if (accuracyOrObj && typeof accuracyOrObj === 'object') {
    accuracy = accuracyOrObj.accuracy;
    judged = accuracyOrObj.judged;
    minSample = accuracyOrObj.minSample ?? minSample;
  }
  if (!Number.isFinite(accuracy)) return '<span class="soft">not enough evidence</span>';
  const tone = accuracy >= 0.75 ? 'ok' : accuracy >= 0.5 ? 'warn' : 'bad';
  const suffix = judged !== null && judged !== undefined && judged < minSample ? ' <span class="soft tiny">(small sample)</span>' : '';
  return `${badge(fmtPct(accuracy, 0), tone)}${suffix}`;
}

export const confidenceLabel = (value) => (value ? CONFIDENCE_LEVELS[value] || value : '—');

export const questionTypeLabel = (type) => QUESTION_TYPES[type] || type || 'unknown';

/**
 * Answer-key marker for a question.
 *
 * Only the two states that change what the app *does* are surfaced: a key that
 * is missing (the question cannot be judged and is excluded from scoring) and a
 * key that is disputed (the user must decide which answer judges it). Where a
 * key came from — the book, a coach, an official release — is deliberately not
 * shown anywhere in the interface.
 */
export function answerKeyBadge(status) {
  const labels = { missing: ['Answer key missing', 'bad'], disputed: ['Answer key disputed', 'bad'] };
  const entry = labels[status];
  return entry ? badge(entry[0], entry[1]) : '';
}

export function languageSwitcher(question, activeLang, { languages = null } = {}) {
  const available = languages || Object.keys(question.language_variants || {});
  if (available.length < 2) return '';
  return `<span class="seg" role="group" aria-label="Question language" data-lang-switch>
    ${available
      .map(
        (lang) =>
          `<button type="button" data-lang="${esc(lang)}"${lang === 'hi' ? ' lang="hi"' : ''} aria-pressed="${lang === activeLang}">${esc(LANGUAGE_LABELS[lang] || lang)}</button>`,
      )
      .join('')}
  </span>`;
}

/**
 * Render the explanation block. Explanations are the prose that came with the
 * bank and are shown exactly as supplied; when a record has none the app says so
 * instead of filling the space in, because it never writes an explanation itself.
 */
export function renderExplanation(question) {
  const explanation = question.explanation;
  if (!explanation) {
    return `<div class="explanation"><h3>Explanation</h3><p class="muted small m-0">No explanation was supplied with this question. Explanations arrive with the question bank; this app does not write them, and it will not show filler text.</p></div>`;
  }
  const rows = (explanation.option_explanations || []).filter((o) => o.text);
  return `<div class="explanation">
    <h3>Explanation</h3>
    ${explanation.correct_reasoning ? `<p${langAttr(explanation.correct_reasoning)}>${esc(explanation.correct_reasoning)}</p>` : ''}
    ${
      rows.length
        ? `<h3>Option by option</h3><div class="table-wrap"><table class="data compact options-table"><tbody>${rows
            .map(
              (o) =>
                `<tr><td class="mono col-key">${esc(o.key || '—')}</td><td${langAttr(o.text)}>${esc(o.text)}${
                  o.reason ? `<div class="soft small option-reason"${langAttr(o.reason)}>${esc(o.reason)}</div>` : ''
                }</td><td class="col-status">${o.is_correct === true ? badge('correct', 'ok') : o.is_correct === false ? badge('not correct', 'plain') : '<span class="soft tiny">unstated</span>'}</td></tr>`,
            )
            .join('')}</tbody></table></div>`
        : ''
    }
    ${explanation.key_concepts?.length ? `<h3>Related concepts</h3><div class="chips">${explanation.key_concepts.map((c) => `<span class="chip"${langAttr(c)}>${esc(c)}</span>`).join('')}</div>` : ''}
    ${explanation.revision_takeaways?.length ? `<h3>Revision takeaways</h3><ul class="small">${explanation.revision_takeaways.map((t) => `<li${langAttr(t)}>${esc(t)}</li>`).join('')}</ul>` : ''}
    ${
      explanation.sources?.length
        ? `<h3>Sources</h3><ul class="small">${explanation.sources
            .map(
              (s) =>
                `<li>${esc(s.title || s.citation || 'source')}${s.url ? ` — <a href="${esc(s.url)}" rel="noopener noreferrer">link</a>` : ''}${s.citation && s.title ? `<br><span class="soft">${esc(s.citation)}</span>` : ''}</li>`,
            )
            .join('')}</ul>`
        : ''
    }
  </div>`;
}

/** Warning list shown wherever authenticity or completeness is in question. */
export function warningList(warnings, { title = 'Read before you start' } = {}) {
  if (!warnings?.length) return '';
  return notice(`<ul>${warnings.map((w) => `<li>${esc(w)}</li>`).join('')}</ul>`, 'warn', { title });
}

/* ------------------------------------------------------------------ tabs -- */

/**
 * Accessible tablist implementing the WAI-ARIA Authoring Practices Guide (APG)
 * roving tabindex pattern (Left/Right/Home/End keys).
 * Supports both `{ id, items: [{ id, label, body }], activeId }` and `{ items: [{ id, label, content }], active }`.
 */
export function tabs({ id = '', items = [], activeId = null, active = null } = {}) {
  if (!items.length) return '';
  const selectedId = activeId || active || items[0].id;
  return `<div class="tabs" role="tablist" ${id ? `id="${esc(id)}"` : ''}>
    ${items
      .map((item) => {
        const isSelected = item.id === selectedId;
        return `<button class="tab" role="tab" type="button" data-tab="${esc(item.id)}" aria-selected="${isSelected}" tabindex="${isSelected ? '0' : '-1'}" aria-controls="${esc(item.id)}-panel" id="${esc(item.id)}-tab">${esc(item.label)}</button>`;
      })
      .join('')}
  </div>
  ${items
    .map((item) => {
      const isSelected = item.id === selectedId;
      const panelHtml = item.body ?? item.content ?? '';
      return `<div class="tabpanel" id="${esc(item.id)}-panel" role="tabpanel" tabindex="0" aria-labelledby="${esc(item.id)}-tab" ${isSelected ? '' : 'hidden'}>${panelHtml}</div>`;
    })
    .join('')}`;
}

export function mountTabs(root, onChange = null) {
  if (!root) return;
  const activateTab = (tab, { focus = false } = {}) => {
    const bar = tab.closest('.tabs');
    if (!bar) return;
    const allTabs = Array.from(bar.querySelectorAll('.tab'));
    allTabs.forEach((t) => {
      const selected = t === tab;
      t.setAttribute('aria-selected', String(selected));
      t.setAttribute('tabindex', selected ? '0' : '-1');
      const panelId = `${t.dataset.tab}-panel`;
      const panel = root.querySelector(`#${CSS.escape ? CSS.escape(panelId) : panelId}`);
      if (panel) panel.hidden = !selected;
    });
    if (focus) tab.focus();
    if (typeof onChange === 'function') onChange(tab.dataset.tab);
  };

  root.querySelectorAll('.tabs').forEach((bar) => {
    const allTabs = Array.from(bar.querySelectorAll('.tab'));
    allTabs.forEach((tab) => {
      tab.addEventListener('click', () => activateTab(tab, { focus: false }));
      tab.addEventListener('keydown', (ev) => {
        const idx = allTabs.indexOf(tab);
        if (idx === -1) return;
        let nextIdx = -1;
        if (ev.key === 'ArrowRight' || ev.key === 'ArrowDown') {
          nextIdx = (idx + 1) % allTabs.length;
        } else if (ev.key === 'ArrowLeft' || ev.key === 'ArrowUp') {
          nextIdx = (idx - 1 + allTabs.length) % allTabs.length;
        } else if (ev.key === 'Home') {
          nextIdx = 0;
        } else if (ev.key === 'End') {
          nextIdx = allTabs.length - 1;
        }
        if (nextIdx !== -1) {
          ev.preventDefault();
          activateTab(allTabs[nextIdx], { focus: true });
        }
      });
    });
  });
}

/* ----------------------------------------------------------- modal/toast -- */

const MAX_TOASTS = 4;

export function toast(message, tone = 'info', timeout = 5200) {
  const stack = document.getElementById('toastStack');
  if (!stack) return null;

  while (stack.children.length >= MAX_TOASTS) {
    stack.firstElementChild?.remove();
  }

  const node = document.createElement('div');
  node.className = `toast ${tone}`;
  node.setAttribute('role', tone === 'bad' ? 'alert' : 'status');
  const bodyHtml = typeof message === 'string' ? esc(message) : String(message);
  node.innerHTML = `<div class="toast-body">${bodyHtml}</div><button class="toast-close" type="button" aria-label="Dismiss notification">✕</button>`;
  stack.appendChild(node);

  let timer = null;
  const startTimer = () => {
    if (timeout <= 0) return;
    clearTimeout(timer);
    timer = setTimeout(() => {
      node.remove();
    }, timeout);
    timer?.unref?.();
  };
  const pauseTimer = () => {
    clearTimeout(timer);
  };

  node.querySelector('.toast-close')?.addEventListener('click', () => {
    clearTimeout(timer);
    node.remove();
  });
  node.addEventListener('mouseenter', pauseTimer);
  node.addEventListener('mouseleave', startTimer);
  node.addEventListener('focusin', pauseTimer);
  node.addEventListener('focusout', startTimer);

  startTimer();
  return node;
}

let modalCleanup = null;
let modalTitleCounter = 0;

function getFocusableElements(container) {
  if (!container) return [];
  return Array.from(
    container.querySelectorAll(
      'button:not([disabled]), [href], input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])',
    ),
  ).filter((el) => !el.closest('[hidden]'));
}

function setBackgroundInert(isInert) {
  for (const id of ['appHeader', 'appBody', 'main']) {
    const el = document.getElementById(id);
    if (!el) continue;
    el.inert = isInert;
    if (isInert) el.setAttribute('inert', '');
    else el.removeAttribute('inert');
  }
  document.body?.classList.toggle('modal-open', isInert);
}

/**
 * Open an accessible modal dialog with focus move, Tab/Shift+Tab focus trap,
 * Escape and backdrop click dismissal, background inert + scroll lock, and
 * focus restoration to the opener.
 */
export function openModal({ title, body, actions = [], wide = false, onMount = null, dismissible = true }) {
  const root = document.getElementById('modalRoot');
  if (!root) return Promise.resolve(null);
  if (modalCleanup) {
    document.removeEventListener('keydown', modalCleanup, true);
    modalCleanup = null;
  }
  const opener = document.activeElement && typeof document.activeElement.focus === 'function' ? document.activeElement : null;
  const titleId = `modalTitle-${++modalTitleCounter}`;

  return new Promise((resolve) => {
    let onKeyDown = null;
    let modal = null;
    let closed = false;
    const close = (value) => {
      if (closed) return;
      closed = true;
      // Hide at once, but keep the markup until the caller has read it.
      // Callers read their fields after the promise settles
      // (`await openModal(...)`, then `document.getElementById(...)`). This
      // used to empty the root before resolving, so every such read returned
      // null: a new item always "needed a title", and the plan editor saved
      // its defaults over the target date and notes the reader had typed. The
      // markup is released on the next task, after the awaiting code has run,
      // unless another dialog has replaced it in the meantime.
      root.hidden = true;
      const leaving = modal;
      setTimeout(() => {
        if (root.hidden && root.firstElementChild === leaving) root.innerHTML = '';
      }, 0);
      setBackgroundInert(false);
      if (onKeyDown) {
        document.removeEventListener('keydown', onKeyDown, true);
        if (modalCleanup === onKeyDown) modalCleanup = null;
        onKeyDown = null;
      }
      if (opener && typeof opener.focus === 'function' && document.contains(opener)) {
        try {
          opener.focus();
        } catch {
          /* ignore focus restoration failure in detached nodes */
        }
      }
      resolve(value);
    };

    root.hidden = false;
    setBackgroundInert(true);

    root.innerHTML = `<div class="modal ${wide ? 'wide' : ''}" role="dialog" aria-modal="true" aria-labelledby="${titleId}" aria-label="${esc(title)}" tabindex="-1">
      <div class="modal-head"><h2 id="${titleId}">${esc(title)}</h2><button class="btn btn-quiet btn-icon" type="button" data-modal-close aria-label="Close">✕</button></div>
      <div class="modal-body" id="modalBody">${body}</div>
      ${
        actions.length
          ? `<div class="modal-foot">${actions
              .map(
                (a, i) =>
                  `<button class="btn ${a.tone || ''}" type="button" data-modal-action="${i}" data-value="${esc(a.value ?? a.label)}">${esc(a.label)}</button>`,
              )
              .join('')}</div>`
          : ''
      }
    </div>`;

    modal = root.firstElementChild;
    modal.querySelectorAll('[data-modal-action]').forEach((btn) => {
      btn.addEventListener('click', () => close(btn.dataset.value));
    });
    modal.querySelectorAll('[data-modal-close]').forEach((btn) => btn.addEventListener('click', () => close(null)));
    root.onclick = (ev) => {
      if (ev.target === root && dismissible) close(null);
    };

    onKeyDown = (ev) => {
      if (ev.key === 'Escape' && dismissible) {
        ev.preventDefault();
        close(null);
        return;
      }
      if (ev.key === 'Tab') {
        const focusables = getFocusableElements(modal);
        if (!focusables.length) {
          ev.preventDefault();
          modal.focus();
          return;
        }
        const first = focusables[0];
        const last = focusables[focusables.length - 1];
        const active = document.activeElement;
        if (ev.shiftKey) {
          if (active === first || !modal.contains(active)) {
            ev.preventDefault();
            last.focus();
          }
        } else if (active === last || !modal.contains(active)) {
          ev.preventDefault();
          first.focus();
        }
      }
    };
    modalCleanup = onKeyDown;
    document.addEventListener('keydown', onKeyDown, true);

    if (onMount) {
      try {
        onMount(modal, close);
      } catch (err) {
        console.error('Modal mount failed', err);
        toast(`The dialog could not be prepared: ${err.message}`, 'bad');
      }
    }

    // Move initial focus inside the dialog if onMount did not already focus an element inside it.
    if (!modal.contains(document.activeElement)) {
      const focusables = getFocusableElements(modal);
      const preferred =
        modal.querySelector('[data-modal-action][ class*="btn-primary" ]') ||
        modal.querySelector('input:not([type="hidden"]), select, textarea') ||
        focusables[0] ||
        modal;
      preferred?.focus?.();
    }
  });
}

export function confirmDialog({ title = 'Please confirm', message, confirmLabel = 'Confirm', cancelLabel = 'Cancel', danger = false }) {
  return openModal({
    title,
    body: `<p>${message}</p>`,
    actions: [
      { label: cancelLabel, value: 'cancel' },
      { label: confirmLabel, tone: danger ? 'btn-danger' : 'btn-primary', value: 'confirm' },
    ],
  }).then((value) => value === 'confirm');
}

export function promptDialog({ title, label, value = '', multiline = false, confirmLabel = 'Save', placeholder = '' }) {
  const fieldId = 'promptField';
  return openModal({
    title,
    body: `<label class="field"><span class="label-text">${esc(label)}</span>${
      multiline
        ? `<textarea id="${fieldId}" placeholder="${esc(placeholder)}">${esc(value)}</textarea>`
        : `<input type="text" id="${fieldId}" value="${esc(value)}" placeholder="${esc(placeholder)}" />`
    }</label>`,
    actions: [
      { label: 'Cancel', value: '__cancel' },
      { label: confirmLabel, tone: 'btn-primary', value: '__confirm' },
    ],
    onMount: (modal) => {
      const input = modal.querySelector(`#${fieldId}`);
      if (input) {
        input.focus();
        input.addEventListener('keydown', (ev) => {
          if (ev.key === 'Enter' && !multiline) modal.querySelector('[data-value="__confirm"]')?.click();
        });
      }
    },
  }).then((result) => {
    if (result === '__confirm') {
      const input = document.getElementById(fieldId);
      return input ? input.value : value;
    }
    return null;
  });
}

/** Simple radio/checkbox list builder used by setup screens and settings. */
export function optionList(name, options, selected) {
  return `<div class="stack mb-2">${options
    .map(
      (opt) => `<label class="check"><input type="radio" name="${esc(name)}" value="${esc(opt.value)}" ${String(opt.value) === String(selected) ? 'checked' : ''} />
      <span><strong>${esc(opt.label)}</strong>${opt.hint ? `<span class="hint block">${esc(opt.hint)}</span>` : ''}</span></label>`,
    )
    .join('')}</div>`;
}

export const stat = (label, value, sub = '') => tile({ label, value, sub });

/* ------------------------------------------------------------- the desk -- */
/*
 * Phase 3 primitives. `card()` remains for the screens that genuinely hold a
 * bounded object (a bank import, a dialog body); these replace it everywhere a
 * screen used it only because there was no other container.
 *
 *   sheet()        a section of the page, separated by a hairline
 *   marginNote()   the metadata column: provenance, sample size, "why this"
 *   metaLine()     one line of facts, separated by space instead of middots
 *   stamp()        the one date that matters, in a queue's gutter
 *   segmented()    three counts as one bar with a text legend
 */

/**
 * A section of the page. Deliberately not a card: no border, no shadow, no
 * nested containers — a hairline above it and rhythm inside it.
 */
export function sheet({ label = '', title = '', subtitle = '', count = null, action = '', actions = '', info = '', right = '', body = '', footer = '', id = null, className = '' } = {}) {
  const act = [right, actions, action].filter(Boolean).join(' ');
  const head =
    label || title || act || count !== null || info
      ? `<div class="sheet-head">
          <div>
            ${label ? `<h2 class="section-label">${esc(label)}</h2>` : ''}
            ${title ? `<h2 class="m-0">${title}</h2>` : ''}
            ${subtitle ? `<p class="sheet-sub">${subtitle}</p>` : ''}
          </div>
          <div class="sheet-action">${count !== null ? `<span class="small text-soft">${esc(String(count))}</span>` : ''}${info}${act}</div>
        </div>`
      : '';
  return `<section class="sheet ${esc(className)}"${id ? ` id="${esc(id)}"` : ''}>
    ${head}
    ${body}
    ${footer ? `<div class="sheet-foot mt-2">${footer}</div>` : ''}
  </section>`;
}

/** The margin: facts written beside the thing they describe, never badges. */
export function marginNote(body, { title = '' } = {}) {
  return `<aside class="margin-note">${title ? `<div class="margin-note-title">${icon('shield', { size: 18 })}<h2 class="section-label">${esc(title)}</h2></div>` : ''}${body}</aside>`;
}

/** Facts on one line, separated by space. `items` may contain markup. */
export function metaLine(items = []) {
  const parts = items.filter(Boolean);
  if (!parts.length) return '';
  return `<p class="meta-line">${parts.map((item) => `<span>${item}</span>`).join('')}</p>`;
}

/** The one date that matters. `tone: 'now'` is the margin red. */
export function stamp(text, { tone = '', as: Tag = 'span' } = {}) {
  return `<${Tag} class="stamp${tone === 'now' ? ' is-now' : ''}">${esc(text)}</${Tag}>`;
}

/** Round a percentage to the nearest 5 for a class-based width (no inline styles). */
function pctStep(value) {
  return Math.max(0, Math.min(100, Math.round((Number(value) || 0) / 5) * 5));
}

/**
 * A result as one bar: correct (ink), wrong (margin red), blank (outline).
 * The legend is text, so the bar is never the only way to read the numbers.
 */
export function segmented(parts = [], { label = '' } = {}) {
  const total = parts.reduce((sum, part) => sum + (Number(part.value) || 0), 0) || 1;
  const tones = { ok: 'is-ok', bad: 'is-bad', blank: 'is-blank' };
  return `<div class="segmented" role="img" aria-label="${esc(label || parts.map((p) => `${p.label} ${p.value}`).join(', '))}">
      ${parts
        .filter((part) => Number(part.value) > 0)
        .map((part) => `<i class="${tones[part.tone] || 'is-ok'}" data-pct="${pctStep(((Number(part.value) || 0) / total) * 100)}"></i>`)
        .join('')}
    </div>
    <p class="seg-legend">${parts
      .map((part) => `<span>${part.tone === 'bad' ? '▪' : part.tone === 'blank' ? '▫' : '▪'} ${esc(part.label)} <b>${esc(String(part.value))}</b></span>`)
      .join('')}</p>`;
}

/** A row whose whole surface is the action. */
export function deskRow({ href = null, mark = '◆', title, detail = '', right = '', onClickAction = null } = {}) {
  const inner = `<span class="desk-mark" aria-hidden="true">${mark}</span>
    <span class="desk-title">${title}${detail ? ` <em>— ${detail}</em>` : ''}</span>
    <span class="desk-count">${right}</span>`;
  if (href) return `<li><a class="desk-row" href="${esc(href)}">${inner}</a></li>`;
  return `<li><span class="desk-row"${onClickAction ? ` role="presentation"` : ''}>${inner}</span></li>`;
}

/** Evidence as three dots: how much is known, at a glance. */
export function evidenceDots(judged, { max = 3 } = {}) {
  const on = Math.max(0, Math.min(max, Number(judged) || 0));
  return `<span class="dots" role="img" aria-label="${on ? `evidence: ${on} of ${max}` : 'no evidence yet'}">${Array.from({ length: max }, (_, i) => `<i class="${i < on ? 'on' : ''}"></i>`).join('')}</span>`;
}

/**
 * A row of accuracy bars — the report's and Insights' one visual for "where is
 * it weak". Every row carries its own sample size beside the figure.
 */
export function barRows(rows = [], { empty = '' } = {}) {
  if (!rows.length) return empty ? `<p class="muted small m-0">${esc(empty)}</p>` : '';
  return `<table class="bar-rows"><tbody>${rows
    .map(
      (row) => `<tr>
        <td class="row-name">${row.name}</td>
        <td class="bar-track"><span><i data-pct="${pctStep(Math.max(0, Math.min(1, Number(row.value) || 0)) * 100)}"></i></span></td>
        <td class="row-value">${esc(String(row.valueLabel ?? ''))}</td>
        <td class="row-act">${row.action || ''}</td>
      </tr>`,
    )
    .join('')}</tbody></table>`;
}
